package de.intarsys.nativec.jna;

import de.intarsys.nativec.api.ICallback;

public class JnaNativeCallbackStd extends JnaNativeCallback {

	public JnaNativeCallbackStd(ICallback pCallback) {
		super(pCallback);
	}

}
