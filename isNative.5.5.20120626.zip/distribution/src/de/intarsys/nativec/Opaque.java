package de.intarsys.nativec;

import de.intarsys.nativec.type.NativeVoid;

public class Opaque extends PseudoObject<NativeVoid> {

	public Opaque(NativeVoid nativeObject) {
		super(nativeObject);
	}

}
